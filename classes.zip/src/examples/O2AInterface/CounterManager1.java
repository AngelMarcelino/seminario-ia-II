package examples.O2AInterface;

/**
 * interface exposes the methods of the agent that you want to provide application
 * 
 * @author Giovanni Iavarone - Michele Izzo
 */
public interface CounterManager1 {
	public void activateCounter();
}


