package mlr;

import java.util.ArrayList;

import utils.DataTriplet;

public class MLRCramerStrategy implements MLRStrategy {

  @Override
  public DataTriplet calculate(ArrayList<DataTriplet> data) {
    return null;
  }

}
